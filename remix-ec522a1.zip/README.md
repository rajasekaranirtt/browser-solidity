# Automatic build
Built website from `ec522a1`. See https://github.com/ethereum/browser-solidity/ for details.
To use an offline copy, download `remix-ec522a1.zip`.
